"""Seed demo data. Run: cd backend && python seed.py"""
import sys, os
sys.path.insert(0, os.path.dirname(__file__))
import db
from werkzeug.security import generate_password_hash
from datetime import datetime, timedelta

# Wipe and recreate
if os.path.exists(db.DB_PATH):
    os.remove(db.DB_PATH)
db.init_db()

conn = db.get_conn()
conn.execute("DELETE FROM timeline_events"); conn.execute("DELETE FROM documents")
conn.execute("DELETE FROM notifications"); conn.execute("DELETE FROM applications")
conn.execute("DELETE FROM users"); conn.commit(); conn.close()

# ── USERS ─────────────────────────────────────────────────────────────────────
admin    = db.create_user('Admin User',    'admin@parivesh.gov.in',  generate_password_hash('admin123'),  'Admin',   'Ministry of Environment')
pp       = db.create_user('Rahul Verma',   'rahul@infra.com',        generate_password_hash('test123'),   'PP',      '')
scrutiny = db.create_user('Priya Sharma',  'priya@scrutiny.gov.in',  generate_password_hash('test123'),   'Scrutiny','Scrutiny Division')
mom      = db.create_user('Anil Mehta',    'anil@mom.gov.in',        generate_password_hash('test123'),   'MoM',     'MoM Secretariat')

# ── APPLICATION 1: Under Scrutiny ──────────────────────────────────────────────
c = db.get_conn()
c.execute("""INSERT INTO applications (id,project_name,sector,category,location,description,status,created_by,assigned_officer,created_at,updated_at)
             VALUES ('EC-DEMO001','Coastal Highway Extension – Phase 2','Infrastructure','B1','Raigad, Maharashtra',
             '6-lane coastal highway extension from Alibaug to Rewas.','UnderScrutiny',?,?,
             datetime('now','-4 days'),datetime('now','-2 days'))""", (pp['id'], scrutiny['id']))
c.commit(); c.close()

base = datetime.utcnow() - timedelta(days=4)
for dt_offset, aid, uname, dept, etype, msg, sat in [
    (0,   pp['id'],       pp['name'],       'Applicant',        'submission', 'Application created as Draft.',                         'Draft'),
    (2,   pp['id'],       pp['name'],       'Applicant',        'submission', 'Application submitted. 2 document(s) uploaded.',         'Submitted'),
    (5,   scrutiny['id'], scrutiny['name'], 'Scrutiny Division','verification',f'Application taken up for scrutiny by {scrutiny["name"]}.','UnderScrutiny'),
]:
    c = db.get_conn()
    c.execute("""INSERT INTO timeline_events (application_id,datetime,actor_id,actor_name,department,event_type,message,status_after_event)
                 VALUES ('EC-DEMO001',?,?,?,?,?,?,?)""",
              ((base+timedelta(hours=dt_offset)).isoformat(), aid, uname, dept, etype, msg, sat))
    c.commit(); c.close()

# ── APPLICATION 2: EDS Stage ───────────────────────────────────────────────────
c = db.get_conn()
c.execute("""INSERT INTO applications (id,project_name,sector,category,location,description,status,created_by,assigned_officer,created_at,updated_at)
             VALUES ('EC-DEMO002','Solar Farm – Rajasthan Grid','Energy','A','Jodhpur, Rajasthan',
             '500 MW utility-scale solar PV project.','EDS',?,?,
             datetime('now','-6 days'),datetime('now','-3 days'))""", (pp['id'], scrutiny['id']))
c.commit(); c.close()

base2 = datetime.utcnow() - timedelta(days=6)
for dt_h, aid, uname, dept, etype, msg, sat in [
    (0,  pp['id'],       pp['name'],       'Applicant',         'submission',  'Application submitted. EIA Report uploaded.',       'Submitted'),
    (8,  scrutiny['id'], scrutiny['name'], 'Scrutiny Division', 'verification','Application taken for scrutiny.',                   'UnderScrutiny'),
    (14, scrutiny['id'], scrutiny['name'], 'Scrutiny Division', 'issue',       'EDS Raised.\nIssue: Groundwater impact assessment incomplete.\nRequested Document: Hydrogeological Study Report','EDS'),
]:
    c = db.get_conn()
    c.execute("""INSERT INTO timeline_events (application_id,datetime,actor_id,actor_name,department,event_type,message,status_after_event)
                 VALUES ('EC-DEMO002',?,?,?,?,?,?,?)""",
              ((base2+timedelta(hours=dt_h)).isoformat(), aid, uname, dept, etype, msg, sat))
    c.commit(); c.close()

# ── APPLICATION 3: Finalized ───────────────────────────────────────────────────
c = db.get_conn()
c.execute("""INSERT INTO applications (id,project_name,sector,category,location,description,status,created_by,created_at,updated_at)
             VALUES ('EC-DEMO003','Cement Plant Expansion – Unit 3','Industry','A','Satna, Madhya Pradesh',
             'Expansion of existing cement plant from 2 MTPA to 4 MTPA.','Finalized',?,
             datetime('now','-30 days'),datetime('now','-5 days'))""", (pp['id'],))
c.commit(); c.close()

base3 = datetime.utcnow() - timedelta(days=30)
stages = [
    (0,  pp['id'],       pp['name'],       'Applicant',         'submission',  'Application submitted.',                                   'Submitted'),
    (3,  scrutiny['id'], scrutiny['name'], 'Scrutiny Division', 'verification','Application taken for scrutiny.',                          'UnderScrutiny'),
    (6,  scrutiny['id'], scrutiny['name'], 'Scrutiny Division', 'issue',       'EDS Raised.\nIssue: Stack emission data missing.',         'EDS'),
    (9,  pp['id'],       pp['name'],       'Applicant',         'response',    'EDS response submitted with updated emission reports.',     'Resubmitted'),
    (12, scrutiny['id'], scrutiny['name'], 'Scrutiny Division', 'verification','Documents verified. Application cleared for referral.',     'UnderScrutiny'),
    (15, scrutiny['id'], scrutiny['name'], 'Scrutiny Division', 'meeting',     'Application referred to Expert Appraisal Committee.',      'Referred'),
    (18, mom['id'],      mom['name'],      'MoM Secretariat',   'meeting',     'Minutes of Meeting generated.\nDiscussion: Committee recommends clearance with standard conditions on emission controls.','MoMGenerated'),
    (21, admin['id'],    admin['name'],    'Ministry',          'decision',    'Environmental Clearance GRANTED with standard conditions.','Finalized'),
]
for dt_d, aid, uname, dept, etype, msg, sat in stages:
    c = db.get_conn()
    c.execute("""INSERT INTO timeline_events (application_id,datetime,actor_id,actor_name,department,event_type,message,status_after_event)
                 VALUES ('EC-DEMO003',?,?,?,?,?,?,?)""",
              ((base3+timedelta(days=dt_d)).isoformat(), aid, uname, dept, etype, msg, sat))
    c.commit(); c.close()

# Sample notifications
db.create_notification(pp['id'], 'EC-DEMO001', 'Scrutiny Started', 'Your application EC-DEMO001 is now under scrutiny.')
db.create_notification(pp['id'], 'EC-DEMO002', 'EDS Raised', 'An EDS has been raised on EC-DEMO002. Please respond.')
db.notify_role('Scrutiny', 'EC-DEMO001', 'Application Submitted', 'EC-DEMO001 awaits scrutiny.')

print("✅ Database seeded!")
print("\n  Login credentials:")
print("  Admin:    admin@parivesh.gov.in  / admin123")
print("  PP:       rahul@infra.com        / test123")
print("  Scrutiny: priya@scrutiny.gov.in  / test123")
print("  MoM:      anil@mom.gov.in        / test123")
