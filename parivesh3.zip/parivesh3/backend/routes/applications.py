from flask import Blueprint, request, jsonify, session, send_file, current_app
from werkzeug.utils import secure_filename
from routes.auth import login_required, role_required, current_user
import db, os, uuid

app_bp = Blueprint('applications', __name__)
ALLOWED_EXT = {'pdf', 'docx', 'xlsx'}
MAX_FILE_SIZE = 20 * 1024 * 1024

def allowed_file(filename):
    return '.' in filename and filename.rsplit('.',1)[1].lower() in ALLOWED_EXT

def save_file(file, application_id):
    if not allowed_file(file.filename):
        return None, 'File type not allowed. Only PDF, DOCX, XLSX.'
    file.seek(0,2); size = file.tell(); file.seek(0)
    if size > MAX_FILE_SIZE:
        return None, 'File exceeds 20MB limit'
    ext = file.filename.rsplit('.',1)[1].lower()
    stored = f"{application_id}_{uuid.uuid4().hex[:8]}.{ext}"
    upload_dir = os.path.join(current_app.config['UPLOAD_FOLDER'], application_id)
    os.makedirs(upload_dir, exist_ok=True)
    path = os.path.join(upload_dir, stored)
    file.save(path)
    return os.path.join(application_id, stored), None

# ── CREATE ──────────────────────────────────────────────────────────────────
@app_bp.route('/application/create', methods=['POST'])
@login_required
@role_required('PP','Admin')
def create_application():
    u = current_user()
    data = request.form
    for k in ['project_name','sector','category','location']:
        if not data.get(k):
            return jsonify({'error': f'Missing field: {k}'}), 400
    app = db.create_application(
        project_name=data['project_name'], sector=data['sector'],
        category=data['category'], location=data['location'],
        description=data.get('description',''), created_by=u['id']
    )
    db.create_event(app['id'], u['id'], u['name'], u['department'] or 'Applicant',
                    'submission', 'Application created as Draft.', 'Draft')
    db.log_audit(u['id'],'CREATE_APPLICATION',app['id'],'',request.remote_addr)
    return jsonify({'message':'Application created','application':app}), 201

# ── SUBMIT ───────────────────────────────────────────────────────────────────
@app_bp.route('/application/<app_id>/submit', methods=['POST'])
@login_required
@role_required('PP','Admin')
def submit_application(app_id):
    u = current_user()
    app = db.get_application(app_id)
    if not app: return jsonify({'error':'Not found'}), 404
    if app['created_by'] != u['id'] and u['role'] != 'Admin':
        return jsonify({'error':'Forbidden'}), 403
    if app['status'] != 'Draft':
        return jsonify({'error':'Only Draft applications can be submitted'}), 400

    docs = []
    for key in request.files:
        file = request.files[key]
        doc_type = request.form.get(f'{key}_type', key)
        path, err = save_file(file, app_id)
        if err: return jsonify({'error': err}), 400
        doc = db.create_document(app_id, doc_type, file.filename, path, 1, u['id'])
        docs.append(doc)

    db.update_application_status(app_id, 'Submitted')
    first = docs[0] if docs else None
    db.create_event(app_id, u['id'], u['name'], u['department'] or 'Applicant',
                    'submission',
                    f'Application submitted. {len(docs)} document(s) uploaded.',
                    'Submitted', first['id'] if first else None)
    for doc in docs[1:]:
        db.create_event(app_id, u['id'], u['name'], u['department'] or 'Applicant',
                        'file_upload', f'Document uploaded: {doc["document_type"]}',
                        'Submitted', doc['id'])
    db.notify_role('Scrutiny', app_id, 'New Application Submitted',
                   f'{app_id} – {app["project_name"]} has been submitted.')
    db.log_audit(u['id'],'SUBMIT_APPLICATION',app_id,'',request.remote_addr)
    return jsonify({'message':'Application submitted','application':db.get_application(app_id)})

# ── LIST ──────────────────────────────────────────────────────────────────────
@app_bp.route('/application/list', methods=['GET'])
@login_required
def list_applications():
    u = current_user()
    apps = db.list_applications(
        user_id=u['id'], role=u['role'],
        status=request.args.get('status'),
        sector=request.args.get('sector'),
        search=request.args.get('search','').strip() or None
    )
    return jsonify(apps)

# ── GET ONE ───────────────────────────────────────────────────────────────────
@app_bp.route('/application/<app_id>', methods=['GET'])
@login_required
def get_application(app_id):
    app = db.get_application(app_id)
    if not app: return jsonify({'error':'Not found'}), 404
    return jsonify(app)

# ── BEGIN SCRUTINY ────────────────────────────────────────────────────────────
@app_bp.route('/scrutiny/begin/<app_id>', methods=['POST'])
@login_required
@role_required('Scrutiny','Admin')
def begin_scrutiny(app_id):
    u = current_user()
    app = db.get_application(app_id)
    if not app: return jsonify({'error':'Not found'}), 404
    if app['status'] != 'Submitted':
        return jsonify({'error':'Application must be in Submitted status'}), 400
    db.update_application_status(app_id, 'UnderScrutiny', u['id'])
    db.create_event(app_id, u['id'], u['name'], u['department'] or 'Scrutiny Department',
                    'verification', f'Application taken up for scrutiny by {u["name"]}.',
                    'UnderScrutiny')
    db.create_notification(app['created_by'], app_id, 'Scrutiny Started',
                           f'Your application {app_id} is now under scrutiny.')
    return jsonify({'message':'Scrutiny begun','application':db.get_application(app_id)})

# ── RAISE EDS ─────────────────────────────────────────────────────────────────
@app_bp.route('/scrutiny/raise-eds', methods=['POST'])
@login_required
@role_required('Scrutiny','Admin')
def raise_eds():
    u = current_user()
    data = request.get_json() or {}
    app_id = data.get('application_id')
    app = db.get_application(app_id)
    if not app: return jsonify({'error':'Not found'}), 404
    if app['status'] not in ('UnderScrutiny','Resubmitted'):
        return jsonify({'error':'Invalid status for EDS'}), 400
    issue = data.get('issue_description','')
    req_doc = data.get('requested_document','')
    msg = f'EDS Raised.\nIssue: {issue}'
    if req_doc: msg += f'\nRequested Document: {req_doc}'
    db.update_application_status(app_id, 'EDS')
    db.create_event(app_id, u['id'], u['name'], u['department'] or 'Scrutiny Department',
                    'issue', msg, 'EDS')
    db.create_notification(app['created_by'], app_id, 'EDS Raised',
                           f'An Environmental Data Shortfall has been raised on {app_id}.')
    db.log_audit(u['id'],'RAISE_EDS',app_id,issue,request.remote_addr)
    return jsonify({'message':'EDS raised','application':db.get_application(app_id)})

# ── RESPOND TO EDS ────────────────────────────────────────────────────────────
@app_bp.route('/application/respond', methods=['POST'])
@login_required
@role_required('PP','Admin')
def respond_to_eds():
    u = current_user()
    app_id = request.form.get('application_id')
    app = db.get_application(app_id)
    if not app: return jsonify({'error':'Not found'}), 404
    if app['created_by'] != u['id'] and u['role'] != 'Admin':
        return jsonify({'error':'Forbidden'}), 403
    if app['status'] != 'EDS':
        return jsonify({'error':'Application must be in EDS status'}), 400

    response_text = request.form.get('response_text','')
    updated_docs = []
    for key in request.files:
        file = request.files[key]
        doc_type = request.form.get(f'{key}_type', key)
        prev_doc_id = request.form.get(f'{key}_prev_id')
        path, err = save_file(file, app_id)
        if err: return jsonify({'error': err}), 400
        prev_doc = db.get_document(int(prev_doc_id)) if prev_doc_id else None
        version = (prev_doc['version'] + 1) if prev_doc else 1
        doc = db.create_document(app_id, doc_type, file.filename, path, version,
                                  u['id'], int(prev_doc_id) if prev_doc_id else None)
        updated_docs.append(doc)

    db.update_application_status(app_id, 'Resubmitted')
    msg = 'Response to EDS submitted.'
    if response_text: msg += f'\n{response_text}'
    first = updated_docs[0] if updated_docs else None
    db.create_event(app_id, u['id'], u['name'], u['department'] or 'Applicant',
                    'response', msg, 'Resubmitted', first['id'] if first else None)
    for doc in updated_docs[1:]:
        db.create_event(app_id, u['id'], u['name'], u['department'] or 'Applicant',
                        'file_update', f'Document updated: {doc["document_type"]} (v{doc["version"]})',
                        'Resubmitted', doc['id'])
    db.notify_role('Scrutiny', app_id, 'EDS Response Submitted',
                   f'Applicant has responded to EDS on {app_id}.')
    return jsonify({'message':'Response submitted','application':db.get_application(app_id)})

# ── REFER ─────────────────────────────────────────────────────────────────────
@app_bp.route('/scrutiny/refer/<app_id>', methods=['POST'])
@login_required
@role_required('Scrutiny','Admin')
def refer_to_meeting(app_id):
    u = current_user()
    app = db.get_application(app_id)
    if not app: return jsonify({'error':'Not found'}), 404
    if app['status'] not in ('UnderScrutiny','Resubmitted'):
        return jsonify({'error':'Invalid status'}), 400
    data = request.get_json() or {}
    db.update_application_status(app_id, 'Referred')
    db.create_event(app_id, u['id'], u['name'], u['department'] or 'Scrutiny Department',
                    'meeting',
                    f'Application referred to Expert Appraisal Committee. {data.get("remarks","")}',
                    'Referred')
    db.notify_role('MoM', app_id, 'Application Referred',
                   f'{app_id} has been referred for EAC meeting.')
    db.create_notification(app['created_by'], app_id, 'Application Referred',
                           f'Your application {app_id} has been referred to the EAC.')
    return jsonify({'message':'Referred','application':db.get_application(app_id)})

# ── MOM ───────────────────────────────────────────────────────────────────────
@app_bp.route('/mom/generate', methods=['POST'])
@login_required
@role_required('MoM','Admin')
def generate_mom():
    u = current_user()
    app_id = request.form.get('application_id')
    app = db.get_application(app_id)
    if not app: return jsonify({'error':'Not found'}), 404
    if app['status'] != 'Referred':
        return jsonify({'error':'Application must be in Referred status'}), 400
    discussion = request.form.get('discussion','')
    doc = None
    if 'mom_document' in request.files:
        file = request.files['mom_document']
        path, err = save_file(file, app_id)
        if err: return jsonify({'error': err}), 400
        doc = db.create_document(app_id, 'MoM', file.filename, path, 1, u['id'])
    db.update_application_status(app_id, 'MoMGenerated')
    db.create_event(app_id, u['id'], u['name'], u['department'] or 'MoM Secretariat',
                    'meeting', f'Minutes of Meeting generated.\nDiscussion: {discussion}',
                    'MoMGenerated', doc['id'] if doc else None)
    db.create_notification(app['created_by'], app_id, 'MoM Generated',
                           f'Minutes of Meeting generated for {app_id}.')
    return jsonify({'message':'MoM generated','application':db.get_application(app_id)})

# ── FINALIZE ──────────────────────────────────────────────────────────────────
@app_bp.route('/application/<app_id>/finalize', methods=['POST'])
@login_required
@role_required('Admin','MoM')
def finalize(app_id):
    u = current_user()
    app = db.get_application(app_id)
    if not app: return jsonify({'error':'Not found'}), 404
    if app['status'] != 'MoMGenerated':
        return jsonify({'error':'Application must be in MoMGenerated status'}), 400
    data = request.get_json() or {}
    db.update_application_status(app_id, 'Finalized')
    db.create_event(app_id, u['id'], u['name'], u['department'] or 'Ministry',
                    'decision',
                    f'Environmental Clearance {data.get("decision","GRANTED")}. {data.get("remarks","")}',
                    'Finalized')
    db.create_notification(app['created_by'], app_id, 'Final Decision',
                           f'A final decision has been made on {app_id}.')
    return jsonify({'message':'Finalized','application':db.get_application(app_id)})

# ── TIMELINE ──────────────────────────────────────────────────────────────────
@app_bp.route('/timeline/<app_id>', methods=['GET'])
@login_required
def get_timeline(app_id):
    return jsonify(db.get_timeline(app_id, request.args.get('type')))

# ── DOCUMENTS ─────────────────────────────────────────────────────────────────
@app_bp.route('/documents/<app_id>', methods=['GET'])
@login_required
def get_documents(app_id):
    return jsonify(db.get_documents_for_app(app_id))

@app_bp.route('/download/<int:doc_id>', methods=['GET'])
@login_required
def download_document(doc_id):
    doc = db.get_document(doc_id)
    if not doc: return jsonify({'error':'Not found'}), 404
    path = os.path.join(current_app.config['UPLOAD_FOLDER'], doc['file_path'])
    if not os.path.exists(path): return jsonify({'error':'File not found on server'}), 404
    return send_file(path, as_attachment=True, download_name=doc['original_name'])

# ── NOTIFICATIONS ─────────────────────────────────────────────────────────────
@app_bp.route('/notifications', methods=['GET'])
@login_required
def get_notifications():
    u = current_user()
    return jsonify(db.get_notifications(u['id']))

@app_bp.route('/notifications/read', methods=['POST'])
@login_required
def mark_read():
    u = current_user()
    db.mark_all_read(u['id'])
    return jsonify({'message':'Marked as read'})

# ── SEARCH ────────────────────────────────────────────────────────────────────
@app_bp.route('/search', methods=['GET'])
@login_required
def search():
    q = request.args.get('q','').strip()
    if not q: return jsonify([])
    return jsonify(db.list_applications(search=q))
