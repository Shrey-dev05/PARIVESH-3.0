# PARIVESH 3.0 – Environmental Clearance Workflow System

A complete government-grade environmental clearance portal with transparent
workflow tracking, role-based access, document versioning, and full case history.

---

## Quick Start (Local)

```bash
# 1. Clone / unzip the project
cd parivesh3

# 2. Install dependencies (only Flask + Werkzeug needed)
pip install flask werkzeug python-dotenv gunicorn

# 3. Seed the database with demo data
cd backend
python seed.py

# 4. Start the server
python app.py
```

Open http://localhost:5000

---

## Demo Login Credentials

| Role        | Email                       | Password  |
|-------------|-----------------------------|-----------|
| Admin       | admin@parivesh.gov.in       | admin123  |
| Applicant   | rahul@infra.com             | test123   |
| Scrutiny    | priya@scrutiny.gov.in       | test123   |
| MoM         | anil@mom.gov.in             | test123   |

---

## Project Structure

```
parivesh3/
├── backend/
│   ├── app.py              ← Flask app factory (entry point)
│   ├── db.py               ← SQLite database layer (no ORM needed)
│   ├── seed.py             ← Demo data seeder
│   └── routes/
│       ├── auth.py         ← Register, login, logout, user management
│       └── applications.py ← Full workflow API
├── frontend/
│   ├── login.html          ← Login + registration (tab UI)
│   ├── dashboard.html      ← Main application list
│   ├── case_file.html      ← ★ Digital case file + timeline viewer
│   ├── application_form.html ← New application submission
│   ├── scrutiny.html       ← Scrutiny officer queue
│   ├── mom.html            ← MoM secretariat dashboard
│   └── admin.html          ← Admin user management
├── static/
│   ├── css/style.css       ← Government design system
│   └── js/
│       ├── app.js          ← Shared utilities (API, auth, badges)
│       └── shell.js        ← Topbar + sidebar renderer
├── uploads/                ← Secure file storage (not public)
├── requirements.txt
├── Dockerfile
├── docker-compose.yml
├── Procfile               ← For Render / Railway
└── .env.example
```

---

## Workflow Pipeline

```
Draft → Submitted → UnderScrutiny → EDS → Resubmitted → Referred → MoMGenerated → Finalized
```

Each transition is enforced by the backend. Invalid transitions return HTTP 400.

---

## API Endpoints

### Auth
| Method | Endpoint           | Description           |
|--------|--------------------|-----------------------|
| POST   | /api/register      | Create account        |
| POST   | /api/login         | Login (session)       |
| POST   | /api/logout        | Logout                |
| GET    | /api/me            | Current user info     |
| GET    | /api/users         | List users (Admin)    |
| PATCH  | /api/users/:id/role| Update role (Admin)   |

### Applications
| Method | Endpoint                      | Description              |
|--------|-------------------------------|--------------------------|
| POST   | /api/application/create       | Create draft             |
| POST   | /api/application/:id/submit   | Submit with documents    |
| GET    | /api/application/list         | List (filtered)          |
| GET    | /api/application/:id          | Single application       |
| POST   | /api/scrutiny/begin/:id       | Begin scrutiny           |
| POST   | /api/scrutiny/raise-eds       | Raise EDS                |
| POST   | /api/application/respond      | Applicant EDS response   |
| POST   | /api/scrutiny/refer/:id       | Refer to meeting         |
| POST   | /api/mom/generate             | Generate MoM             |
| POST   | /api/application/:id/finalize | Issue final decision     |

### Supporting
| Method | Endpoint                   | Description         |
|--------|----------------------------|---------------------|
| GET    | /api/timeline/:id          | Case file timeline  |
| GET    | /api/documents/:id         | Application docs    |
| GET    | /api/download/:doc_id      | Secure download     |
| GET    | /api/notifications         | User notifications  |
| POST   | /api/notifications/read    | Mark all read       |
| GET    | /api/search?q=             | Global search       |

---

## Deployment

### Option 1: Docker

```bash
cp .env.example .env
# Edit SECRET_KEY in .env
docker-compose up -d
```

### Option 2: Render

1. Push to GitHub
2. Create new Web Service on render.com
3. Set build command: `pip install -r requirements.txt`
4. Set start command: `gunicorn --chdir backend --bind 0.0.0.0:$PORT "app:create_app()"`
5. Set env vars: `SECRET_KEY`, `DB_PATH=/opt/render/project/src/backend/parivesh.db`

### Option 3: Railway

```bash
railway login
railway new
railway up
```
Railway auto-detects the Procfile.

### Option 4: Fly.io

```bash
fly launch
fly secrets set SECRET_KEY=your-secret-key
fly deploy
```

---

## Security Features

- **Passwords** hashed with Werkzeug PBKDF2 (bcrypt-equivalent)
- **Sessions** are server-side (Flask sessions with secret key)
- **File downloads** require authentication — files are never served as public URLs
- **File types** restricted to PDF, DOCX, XLSX only
- **File size** capped at 20MB per upload
- **Role-based** route protection via decorators

---

## Document Versioning

Documents are **never overwritten**. Each upload creates a new record with:
- `version` incremented from previous
- `previous_version_id` linking to the old document

The case file timeline displays:
```
Previous File: EIA_Report_v1.pdf
      ↓
Updated File:  EIA_Report_v2.pdf
```

Both versions remain downloadable.

---

## Scaling to PostgreSQL

Replace the `DB_PATH` env var with a `DATABASE_URL` (PostgreSQL DSN) and
swap the `sqlite3` calls in `db.py` with `psycopg2`. The schema uses only
standard SQL — no SQLite-specific features.

---

## Environment Variables

| Variable     | Description                     | Default                    |
|--------------|---------------------------------|----------------------------|
| SECRET_KEY   | Flask session signing key       | parivesh-dev-secret-2024   |
| DB_PATH      | SQLite database path            | backend/parivesh.db        |
| UPLOAD_FOLDER| File upload directory           | uploads/                   |
