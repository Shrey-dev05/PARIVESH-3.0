const API = '/api';

async function apiFetch(path, options = {}) {
  const res = await fetch(API + path, {
    credentials: 'include',
    headers: { 'Content-Type': 'application/json', ...options.headers },
    ...options
  });
  const data = await res.json().catch(() => ({}));
  if (!res.ok) throw new Error(data.error || `HTTP ${res.status}`);
  return data;
}

async function apiForm(path, formData, method = 'POST') {
  const res = await fetch(API + path, {
    method,
    credentials: 'include',
    body: formData
  });
  const data = await res.json().catch(() => ({}));
  if (!res.ok) throw new Error(data.error || `HTTP ${res.status}`);
  return data;
}

// Session / Auth
async function requireAuth(allowedRoles = null) {
  try {
    const user = await apiFetch('/me');
    if (allowedRoles && !allowedRoles.includes(user.role)) {
      showAlert('Access denied for your role.', 'error');
      setTimeout(() => location.href = '/dashboard', 1500);
      return null;
    }
    return user;
  } catch {
    location.href = '/login';
    return null;
  }
}

function showAlert(msg, type = 'info', container = document.body) {
  const icons = { error: '⚠️', success: '✅', info: 'ℹ️', warning: '⚠️' };
  const el = document.createElement('div');
  el.className = `alert alert-${type}`;
  el.innerHTML = `<span>${icons[type] || ''}</span><span>${msg}</span>`;
  el.style.cssText = 'position:fixed;top:70px;right:20px;z-index:9999;max-width:400px;animation:slideIn 0.3s ease';
  document.body.appendChild(el);
  setTimeout(() => el.remove(), 4000);
}

// Status badge
function statusBadge(status) {
  const map = {
    Draft: 'draft', Submitted: 'submitted', UnderScrutiny: 'scrutiny',
    EDS: 'eds', Resubmitted: 'resubmitted', Referred: 'referred',
    MoMGenerated: 'momgenerated', Finalized: 'finalized'
  };
  const labels = {
    Draft: '⬜ Draft', Submitted: '🔵 Submitted', UnderScrutiny: '🟠 Under Scrutiny',
    EDS: '🔴 EDS', Resubmitted: '🟣 Resubmitted', Referred: '🟢 Referred',
    MoMGenerated: '🩵 MoM Generated', Finalized: '✅ Finalized'
  };
  return `<span class="badge badge-${map[status] || 'draft'}">${labels[status] || status}</span>`;
}

// Format date
function fmtDate(iso) {
  if (!iso) return '–';
  return new Date(iso).toLocaleString('en-IN', {
    day: '2-digit', month: 'short', year: 'numeric',
    hour: '2-digit', minute: '2-digit'
  });
}

function fmtDateShort(iso) {
  if (!iso) return '–';
  return new Date(iso).toLocaleDateString('en-IN', {
    day: '2-digit', month: 'short', year: 'numeric'
  });
}

// Topbar render
async function renderTopbar(user) {
  const initials = user.name.split(' ').map(w => w[0]).join('').slice(0, 2).toUpperCase();
  document.getElementById('user-name').textContent = user.name;
  document.getElementById('user-role').textContent = user.role;
  document.getElementById('user-avatar').textContent = initials;
  loadNotifications();
}

async function loadNotifications() {
  try {
    const notifs = await apiFetch('/notifications');
    const unread = notifs.filter(n => !n.is_read).length;
    const badge = document.getElementById('notif-badge');
    if (badge) {
      badge.textContent = unread;
      badge.style.display = unread ? 'block' : 'none';
    }
    const list = document.getElementById('notif-list');
    if (!list) return;
    if (notifs.length === 0) {
      list.innerHTML = '<div class="empty-state" style="padding:24px"><div class="empty-state-icon">🔔</div><div class="empty-state-text">No notifications</div></div>';
      return;
    }
    list.innerHTML = notifs.map(n => `
      <div class="notif-item ${n.is_read ? '' : 'unread'}" onclick="location.href='/case_file?id=${n.application_id}'">
        <div class="notif-item-title">${n.title}</div>
        <div class="notif-item-msg">${n.message}</div>
        <div class="notif-item-time">${fmtDate(n.created_at)}</div>
      </div>
    `).join('');
  } catch {}
}

function toggleNotifPanel() {
  const panel = document.getElementById('notif-panel');
  panel.classList.toggle('open');
  if (panel.classList.contains('open')) {
    apiFetch('/notifications/read', { method: 'POST' }).then(() => {
      const badge = document.getElementById('notif-badge');
      if (badge) badge.style.display = 'none';
    });
  }
}

async function logout() {
  await apiFetch('/logout', { method: 'POST' }).catch(() => {});
  location.href = '/login';
}

// Close notif panel on outside click
document.addEventListener('click', e => {
  const panel = document.getElementById('notif-panel');
  const btn = document.querySelector('.notif-btn');
  if (panel && !panel.contains(e.target) && btn && !btn.contains(e.target)) {
    panel.classList.remove('open');
  }
});

// CSS animation
const style = document.createElement('style');
style.textContent = `@keyframes slideIn { from { transform: translateX(20px); opacity: 0; } to { transform: none; opacity: 1; } }`;
document.head.appendChild(style);
