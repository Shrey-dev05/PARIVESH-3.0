// shell.js – renders topbar + sidebar + notification panel
function renderShell(activePage, userRole) {
  const navItems = {
    all: [
      { href: '/dashboard', icon: '🏠', label: 'Dashboard', key: 'dashboard' },
      { href: '/case_file', icon: '🗂️', label: 'Search Cases', key: 'search' },
    ],
    PP: [
      { href: '/application_form', icon: '➕', label: 'New Application', key: 'new_app' },
    ],
    Scrutiny: [
      { href: '/scrutiny', icon: '🔍', label: 'Scrutiny Queue', key: 'scrutiny' },
    ],
    MoM: [
      { href: '/mom', icon: '📋', label: 'MoM Dashboard', key: 'mom' },
    ],
    Admin: [
      { href: '/admin', icon: '⚙️', label: 'Admin Panel', key: 'admin' },
      { href: '/scrutiny', icon: '🔍', label: 'Scrutiny View', key: 'scrutiny' },
      { href: '/mom', icon: '📋', label: 'MoM View', key: 'mom' },
    ],
  };

  const roleLinks = [...(navItems.all || []), ...(navItems[userRole] || [])];

  const topbarHtml = `
    <div class="topbar">
      <div class="topbar-brand">
        <div class="brand-emblem">P3</div>
        <div class="brand-text">
          <h1>PARIVESH 3.0</h1>
          <p>Ministry of Environment, Forest &amp; Climate Change</p>
        </div>
      </div>
      <div class="topbar-right">
        <button class="notif-btn" onclick="toggleNotifPanel()" title="Notifications">
          🔔<span class="notif-badge" id="notif-badge" style="display:none">0</span>
        </button>
        <div class="user-chip" onclick="logout()">
          <div class="user-avatar" id="user-avatar">?</div>
          <div class="user-info">
            <div class="user-name" id="user-name">Loading…</div>
            <div class="user-role" id="user-role"></div>
          </div>
          &nbsp;⏻
        </div>
      </div>
    </div>

    <!-- Notification Panel -->
    <div class="notif-panel" id="notif-panel">
      <div class="notif-panel-header">
        <span>🔔 Notifications</span>
        <button onclick="document.getElementById('notif-panel').classList.remove('open')" style="background:none;border:none;cursor:pointer;font-size:18px">×</button>
      </div>
      <div class="notif-list" id="notif-list"></div>
    </div>
  `;

  const sidebarHtml = `
    <div class="sidebar">
      <div class="sidebar-section">
        <div class="sidebar-label">Navigation</div>
        ${roleLinks.map(l => `
          <a href="${l.href}" class="sidebar-link ${activePage === l.key ? 'active' : ''}">
            <span class="sidebar-icon">${l.icon}</span>${l.label}
          </a>
        `).join('')}
      </div>
    </div>
  `;

  return { topbarHtml, sidebarHtml };
}
